/**
 * Sample Test Paths
 * Pre-made test data for validating EchoPath integration
 */

const TestPaths = {
    /**
     * Simple 4-point zigzag
     */
    simple: [
        [0, 0, 0],
        [5, 0, 0],
        [5, 0, 5],
        [10, 0, 5]
    ],

    /**
     * Path with an obstacle in the middle
     */
    withObstacle: [
        [0, 0, 0],
        [3, 0, 2],
        [5, 0, 5],
        [7, 0, 2],
        [10, 0, 0]
    ],

    /**
     * Long complex path
     */
    complex: [
        [0, 0, 0],
        [2, 0, 1],
        [4, 0, 0],
        [6, 0, 2],
        [7, 0, 4],
        [8, 0, 6],
        [10, 0, 7],
        [12, 0, 6],
        [14, 0, 4],
        [15, 0, 2],
        [16, 0, 0]
    ],

    /**
     * Sharp corner path
     */
    sharpCorner: [
        [0, 0, 0],
        [5, 0, 0],
        [5, 0, 5]
    ],

    /**
     * Circular-ish path
     */
    circular: [
        [0, 0, 5],
        [3, 0, 3],
        [5, 0, 0],
        [3, 0, -3],
        [0, 0, -5],
        [-3, 0, -3],
        [-5, 0, 0],
        [-3, 0, 3],
        [0, 0, 5]
    ],

    /**
     * 2D path (for flat games)
     */
    flat2D: [
        [0, 0],
        [5, 2],
        [10, 1],
        [15, 5]
    ]
};

// Expected outputs (for validation)
const ExpectedOutputs = {
    simple: {
        // After smoothing with quality: 'high', density: 12
        pointCount: 49, // 4 waypoints, 12 samples per segment + endpoints
        avgCurvature: 8.5, // degrees (approximate)
        approxLength: 12.0 // units
    },

    withObstacle: {
        // With obstacle at [5, 0, 5], radius: 2.0
        pointCount: 61,
        pathBendsAroundObstacle: true,
        minDistanceToObstacle: 2.5 // Should be > obstacle.radius
    },

    complex: {
        pointCount: 133, // 11 waypoints × 12 samples
        avgCurvature: 12.0,
        approxLength: 22.0
    }
};

// Sample obstacles for testing
const TestObstacles = {
    single: [
        { pos: [5, 0, 5], radius: 2.0 }
    ],

    multiple: [
        { pos: [5, 0, 5], radius: 2.0 },
        { pos: [8, 0, 3], radius: 1.5 },
        { pos: [12, 0, 6], radius: 1.8 }
    ],

    wall: [
        { pos: [5, 0, 0], radius: 1.0 },
        { pos: [5, 0, 1], radius: 1.0 },
        { pos: [5, 0, 2], radius: 1.0 },
        { pos: [5, 0, 3], radius: 1.0 },
        { pos: [5, 0, 4], radius: 1.0 },
        { pos: [5, 0, 5], radius: 1.0 }
    ]
};

// Export for modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { TestPaths, ExpectedOutputs, TestObstacles };
}

// Also attach to window for browser usage
if (typeof window !== 'undefined') {
    window.TestPaths = TestPaths;
    window.ExpectedOutputs = ExpectedOutputs;
    window.TestObstacles = TestObstacles;
}
